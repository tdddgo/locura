import { useState, useMemo, useCallback, useEffect } from "react";
import {
  Star,
  Download,
  Filter,
  Search,
  Calendar,
  Clock,
  MapPin,
  Globe,
  ChevronDown,
  ChevronUp,
  Trophy,
  X,
  Check,
  Bell,
  Zap,
} from "lucide-react";

// ─── MATCH DATABASE ───────────────────────────────────────────────
const MATCHES = [
  // June 11
  { id: 1, group: "A", phase: "Grupos", home: "México", away: "Sudáfrica", date: "2026-06-11", time: "19:00", venue: "Estadio Azteca", city: "Ciudad de México" },
  { id: 2, group: "A", phase: "Grupos", home: "Corea del Sur", away: "Chequia", date: "2026-06-11", time: "22:00", venue: "Estadio Akron", city: "Zapopan" },
  // June 12
  { id: 3, group: "B", phase: "Grupos", home: "Canadá", away: "Bosnia y Herzegovina", date: "2026-06-12", time: "19:00", venue: "BMO Field", city: "Toronto" },
  { id: 4, group: "D", phase: "Grupos", home: "Estados Unidos", away: "Paraguay", date: "2026-06-12", time: "21:00", venue: "SoFi Stadium", city: "Inglewood" },
  // June 13
  { id: 5, group: "B", phase: "Grupos", home: "Qatar", away: "Suiza", date: "2026-06-13", time: "19:00", venue: "Levi's Stadium", city: "Santa Clara" },
  { id: 6, group: "C", phase: "Grupos", home: "Brasil", away: "Marruecos", date: "2026-06-13", time: "18:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 7, group: "C", phase: "Grupos", home: "Haití", away: "Escocia", date: "2026-06-13", time: "21:00", venue: "Gillette Stadium", city: "Foxborough" },
  // June 14
  { id: 8, group: "D", phase: "Grupos", home: "Australia", away: "Turquía", date: "2026-06-14", time: "12:00", venue: "BC Place", city: "Vancouver" },
  { id: 9, group: "E", phase: "Grupos", home: "Alemania", away: "Curazao", date: "2026-06-14", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 10, group: "F", phase: "Grupos", home: "Países Bajos", away: "Japón", date: "2026-06-14", time: "16:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 11, group: "E", phase: "Grupos", home: "Costa de Marfil", away: "Ecuador", date: "2026-06-14", time: "19:00", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 12, group: "F", phase: "Grupos", home: "Suecia", away: "Túnez", date: "2026-06-14", time: "22:00", venue: "Estadio BBVA", city: "Monterrey" },
  // June 15
  { id: 13, group: "H", phase: "Grupos", home: "España", away: "Cabo Verde", date: "2026-06-15", time: "12:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 14, group: "G", phase: "Grupos", home: "Bélgica", away: "Egipto", date: "2026-06-15", time: "15:00", venue: "Lumen Field", city: "Seattle" },
  { id: 15, group: "H", phase: "Grupos", home: "Arabia Saudita", away: "Uruguay", date: "2026-06-15", time: "18:00", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 16, group: "G", phase: "Grupos", home: "Irán", away: "Nueva Zelanda", date: "2026-06-15", time: "21:00", venue: "SoFi Stadium", city: "Inglewood" },
  // June 16
  { id: 17, group: "I", phase: "Grupos", home: "Francia", away: "Senegal", date: "2026-06-16", time: "15:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 18, group: "I", phase: "Grupos", home: "Irak", away: "Noruega", date: "2026-06-16", time: "18:00", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 19, group: "J", phase: "Grupos", home: "Argentina", away: "Argelia", date: "2026-06-16", time: "21:00", venue: "Arrowhead Stadium", city: "Kansas City" },
  // June 17
  { id: 20, group: "J", phase: "Grupos", home: "Austria", away: "Jordania", date: "2026-06-17", time: "00:00", venue: "Levi's Stadium", city: "Santa Clara" },
  { id: 21, group: "K", phase: "Grupos", home: "Portugal", away: "RD Congo", date: "2026-06-17", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 22, group: "L", phase: "Grupos", home: "Inglaterra", away: "Croacia", date: "2026-06-17", time: "16:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 23, group: "L", phase: "Grupos", home: "Ghana", away: "Panamá", date: "2026-06-17", time: "19:00", venue: "BMO Field", city: "Toronto" },
  { id: 24, group: "K", phase: "Grupos", home: "Uzbekistán", away: "Colombia", date: "2026-06-17", time: "22:00", venue: "Estadio Azteca", city: "Ciudad de México" },
  // June 18
  { id: 25, group: "A", phase: "Grupos", home: "Chequia", away: "Sudáfrica", date: "2026-06-18", time: "12:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 26, group: "B", phase: "Grupos", home: "Suiza", away: "Bosnia y Herzegovina", date: "2026-06-18", time: "15:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 27, group: "B", phase: "Grupos", home: "Canadá", away: "Qatar", date: "2026-06-18", time: "18:00", venue: "BC Place", city: "Vancouver" },
  { id: 28, group: "A", phase: "Grupos", home: "México", away: "Corea del Sur", date: "2026-06-18", time: "21:00", venue: "Estadio Akron", city: "Zapopan" },
  // June 19
  { id: 29, group: "D", phase: "Grupos", home: "Estados Unidos", away: "Australia", date: "2026-06-19", time: "15:00", venue: "Lumen Field", city: "Seattle" },
  { id: 30, group: "C", phase: "Grupos", home: "Escocia", away: "Marruecos", date: "2026-06-19", time: "18:00", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 31, group: "C", phase: "Grupos", home: "Brasil", away: "Haití", date: "2026-06-19", time: "20:30", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 32, group: "D", phase: "Grupos", home: "Turquía", away: "Paraguay", date: "2026-06-19", time: "23:00", venue: "Levi's Stadium", city: "Santa Clara" },
  // June 20
  { id: 33, group: "F", phase: "Grupos", home: "Países Bajos", away: "Suecia", date: "2026-06-20", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 34, group: "E", phase: "Grupos", home: "Alemania", away: "Costa de Marfil", date: "2026-06-20", time: "16:00", venue: "BMO Field", city: "Toronto" },
  { id: 35, group: "E", phase: "Grupos", home: "Ecuador", away: "Curazao", date: "2026-06-20", time: "20:00", venue: "Arrowhead Stadium", city: "Kansas City" },
  // June 21
  { id: 36, group: "F", phase: "Grupos", home: "Túnez", away: "Japón", date: "2026-06-21", time: "00:00", venue: "Estadio BBVA", city: "Monterrey" },
  { id: 37, group: "H", phase: "Grupos", home: "España", away: "Arabia Saudita", date: "2026-06-21", time: "12:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 38, group: "G", phase: "Grupos", home: "Bélgica", away: "Irán", date: "2026-06-21", time: "15:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 39, group: "H", phase: "Grupos", home: "Uruguay", away: "Cabo Verde", date: "2026-06-21", time: "18:00", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 40, group: "G", phase: "Grupos", home: "Nueva Zelanda", away: "Egipto", date: "2026-06-21", time: "21:00", venue: "BC Place", city: "Vancouver" },
  // June 22
  { id: 41, group: "J", phase: "Grupos", home: "Argentina", away: "Austria", date: "2026-06-22", time: "13:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 42, group: "I", phase: "Grupos", home: "Francia", away: "Irak", date: "2026-06-22", time: "17:00", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 43, group: "I", phase: "Grupos", home: "Noruega", away: "Senegal", date: "2026-06-22", time: "20:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 44, group: "J", phase: "Grupos", home: "Jordania", away: "Argelia", date: "2026-06-22", time: "23:00", venue: "Levi's Stadium", city: "Santa Clara" },
  // June 23
  { id: 45, group: "K", phase: "Grupos", home: "Portugal", away: "Uzbekistán", date: "2026-06-23", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 46, group: "L", phase: "Grupos", home: "Inglaterra", away: "Ghana", date: "2026-06-23", time: "16:00", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 47, group: "L", phase: "Grupos", home: "Panamá", away: "Croacia", date: "2026-06-23", time: "19:00", venue: "BMO Field", city: "Toronto" },
  { id: 48, group: "K", phase: "Grupos", home: "Colombia", away: "RD Congo", date: "2026-06-23", time: "22:00", venue: "Estadio Akron", city: "Zapopan" },
  // June 24
  { id: 49, group: "B", phase: "Grupos", home: "Suiza", away: "Canadá", date: "2026-06-24", time: "15:00", venue: "BC Place", city: "Vancouver" },
  { id: 50, group: "B", phase: "Grupos", home: "Bosnia y Herzegovina", away: "Qatar", date: "2026-06-24", time: "15:00", venue: "Lumen Field", city: "Seattle" },
  { id: 51, group: "C", phase: "Grupos", home: "Escocia", away: "Brasil", date: "2026-06-24", time: "18:00", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 52, group: "C", phase: "Grupos", home: "Marruecos", away: "Haití", date: "2026-06-24", time: "18:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 53, group: "A", phase: "Grupos", home: "Chequia", away: "México", date: "2026-06-24", time: "21:00", venue: "Estadio Azteca", city: "Ciudad de México" },
  { id: 54, group: "A", phase: "Grupos", home: "Sudáfrica", away: "Corea del Sur", date: "2026-06-24", time: "21:00", venue: "Estadio BBVA", city: "Monterrey" },
  // June 25
  { id: 55, group: "E", phase: "Grupos", home: "Curazao", away: "Costa de Marfil", date: "2026-06-25", time: "16:00", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 56, group: "E", phase: "Grupos", home: "Ecuador", away: "Alemania", date: "2026-06-25", time: "16:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 57, group: "F", phase: "Grupos", home: "Japón", away: "Suecia", date: "2026-06-25", time: "19:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 58, group: "F", phase: "Grupos", home: "Túnez", away: "Países Bajos", date: "2026-06-25", time: "19:00", venue: "Arrowhead Stadium", city: "Kansas City" },
  { id: 59, group: "D", phase: "Grupos", home: "Turquía", away: "Estados Unidos", date: "2026-06-25", time: "22:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 60, group: "D", phase: "Grupos", home: "Paraguay", away: "Australia", date: "2026-06-25", time: "22:00", venue: "Levi's Stadium", city: "Santa Clara" },
  // June 26
  { id: 61, group: "I", phase: "Grupos", home: "Noruega", away: "Francia", date: "2026-06-26", time: "15:00", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 62, group: "I", phase: "Grupos", home: "Senegal", away: "Irak", date: "2026-06-26", time: "15:00", venue: "BMO Field", city: "Toronto" },
  { id: 63, group: "H", phase: "Grupos", home: "Cabo Verde", away: "Arabia Saudita", date: "2026-06-26", time: "20:00", venue: "NRG Stadium", city: "Houston" },
  { id: 64, group: "H", phase: "Grupos", home: "Uruguay", away: "España", date: "2026-06-26", time: "20:00", venue: "Estadio Akron", city: "Zapopan" },
  { id: 65, group: "G", phase: "Grupos", home: "Egipto", away: "Irán", date: "2026-06-26", time: "23:00", venue: "Lumen Field", city: "Seattle" },
  { id: 66, group: "G", phase: "Grupos", home: "Nueva Zelanda", away: "Bélgica", date: "2026-06-26", time: "23:00", venue: "BC Place", city: "Vancouver" },
  // June 27
  { id: 67, group: "L", phase: "Grupos", home: "Panamá", away: "Inglaterra", date: "2026-06-27", time: "17:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 68, group: "L", phase: "Grupos", home: "Croacia", away: "Ghana", date: "2026-06-27", time: "17:00", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 69, group: "K", phase: "Grupos", home: "Colombia", away: "Portugal", date: "2026-06-27", time: "19:30", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 70, group: "K", phase: "Grupos", home: "RD Congo", away: "Uzbekistán", date: "2026-06-27", time: "19:30", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 71, group: "J", phase: "Grupos", home: "Argelia", away: "Austria", date: "2026-06-27", time: "22:00", venue: "Arrowhead Stadium", city: "Kansas City" },
  { id: 72, group: "J", phase: "Grupos", home: "Jordania", away: "Argentina", date: "2026-06-27", time: "22:00", venue: "AT&T Stadium", city: "Arlington" },
  // Round of 32
  { id: 73, group: null, phase: "Octavos", home: "2° Grupo A", away: "2° Grupo B", date: "2026-06-28", time: "15:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 74, group: null, phase: "Octavos", home: "1° Grupo C", away: "2° Grupo F", date: "2026-06-29", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 75, group: null, phase: "Octavos", home: "1° Grupo E", away: "3° (A/B/C/D/F)", date: "2026-06-29", time: "16:30", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 76, group: null, phase: "Octavos", home: "1° Grupo F", away: "2° Grupo C", date: "2026-06-29", time: "21:00", venue: "Estadio BBVA", city: "Monterrey" },
  { id: 77, group: null, phase: "Octavos", home: "2° Grupo E", away: "2° Grupo I", date: "2026-06-30", time: "13:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 78, group: null, phase: "Octavos", home: "1° Grupo I", away: "3° (C/D/F/G/H)", date: "2026-06-30", time: "17:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 79, group: null, phase: "Octavos", home: "1° Grupo A", away: "3° (C/E/F/H/I)", date: "2026-06-30", time: "21:00", venue: "Estadio Azteca", city: "Ciudad de México" },
  { id: 80, group: null, phase: "Octavos", home: "1° Grupo L", away: "3° (E/H/I/J/K)", date: "2026-07-01", time: "12:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 81, group: null, phase: "Octavos", home: "1° Grupo G", away: "3° (A/E/H/I/J)", date: "2026-07-01", time: "16:00", venue: "Lumen Field", city: "Seattle" },
  { id: 82, group: null, phase: "Octavos", home: "1° Grupo D", away: "3° (B/E/F/I/J)", date: "2026-07-01", time: "20:00", venue: "Levi's Stadium", city: "Santa Clara" },
  { id: 83, group: null, phase: "Octavos", home: "1° Grupo H", away: "2° Grupo J", date: "2026-07-02", time: "15:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 84, group: null, phase: "Octavos", home: "2° Grupo K", away: "2° Grupo L", date: "2026-07-02", time: "19:00", venue: "BMO Field", city: "Toronto" },
  { id: 85, group: null, phase: "Octavos", home: "1° Grupo B", away: "3° (E/F/G/I/J)", date: "2026-07-02", time: "23:00", venue: "BC Place", city: "Vancouver" },
  { id: 86, group: null, phase: "Octavos", home: "2° Grupo D", away: "2° Grupo G", date: "2026-07-03", time: "14:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 87, group: null, phase: "Octavos", home: "1° Grupo J", away: "2° Grupo H", date: "2026-07-03", time: "18:00", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 88, group: null, phase: "Octavos", home: "1° Grupo K", away: "3° (D/E/I/J/L)", date: "2026-07-03", time: "21:30", venue: "Arrowhead Stadium", city: "Kansas City" },
  // Round of 16
  { id: 89, group: null, phase: "Cuartos de Octavos", home: "Ganador M73", away: "Ganador M75", date: "2026-07-04", time: "13:00", venue: "NRG Stadium", city: "Houston" },
  { id: 90, group: null, phase: "Cuartos de Octavos", home: "Ganador M74", away: "Ganador M77", date: "2026-07-04", time: "17:00", venue: "Lincoln Financial Field", city: "Filadelfia" },
  { id: 91, group: null, phase: "Cuartos de Octavos", home: "Ganador M76", away: "Ganador M78", date: "2026-07-05", time: "16:00", venue: "MetLife Stadium", city: "East Rutherford" },
  { id: 92, group: null, phase: "Cuartos de Octavos", home: "Ganador M79", away: "Ganador M82", date: "2026-07-05", time: "20:00", venue: "Estadio Azteca", city: "Ciudad de México" },
  { id: 93, group: null, phase: "Cuartos de Octavos", home: "Ganador M80", away: "Ganador M81", date: "2026-07-06", time: "15:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 94, group: null, phase: "Cuartos de Octavos", home: "Ganador M83", away: "Ganador M85", date: "2026-07-06", time: "20:00", venue: "Lumen Field", city: "Seattle" },
  { id: 95, group: null, phase: "Cuartos de Octavos", home: "Ganador M84", away: "Ganador M87", date: "2026-07-07", time: "12:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  { id: 96, group: null, phase: "Cuartos de Octavos", home: "Ganador M86", away: "Ganador M88", date: "2026-07-07", time: "16:00", venue: "BC Place", city: "Vancouver" },
  // Quarterfinals
  { id: 97, group: null, phase: "Cuartos", home: "Ganador M89", away: "Ganador M90", date: "2026-07-09", time: "16:00", venue: "Gillette Stadium", city: "Foxborough" },
  { id: 98, group: null, phase: "Cuartos", home: "Ganador M91", away: "Ganador M92", date: "2026-07-10", time: "15:00", venue: "SoFi Stadium", city: "Inglewood" },
  { id: 99, group: null, phase: "Cuartos", home: "Ganador M93", away: "Ganador M94", date: "2026-07-11", time: "17:00", venue: "Hard Rock Stadium", city: "Miami" },
  { id: 100, group: null, phase: "Cuartos", home: "Ganador M95", away: "Ganador M96", date: "2026-07-11", time: "21:00", venue: "Arrowhead Stadium", city: "Kansas City" },
  // Semifinals
  { id: 101, group: null, phase: "Semifinal", home: "Ganador QF1", away: "Ganador QF2", date: "2026-07-14", time: "15:00", venue: "AT&T Stadium", city: "Arlington" },
  { id: 102, group: null, phase: "Semifinal", home: "Ganador QF3", away: "Ganador QF4", date: "2026-07-15", time: "15:00", venue: "Mercedes-Benz Stadium", city: "Atlanta" },
  // Third place
  { id: 103, group: null, phase: "Tercer puesto", home: "Perdedor SF1", away: "Perdedor SF2", date: "2026-07-18", time: "17:00", venue: "Hard Rock Stadium", city: "Miami" },
  // Final
  { id: 104, group: null, phase: "Final", home: "Ganador SF1", away: "Ganador SF2", date: "2026-07-19", time: "15:00", venue: "MetLife Stadium", city: "East Rutherford" },
];

const GROUPS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"];
const PHASES = ["Grupos", "Octavos", "Cuartos de Octavos", "Cuartos", "Semifinal", "Tercer puesto", "Final"];
const PHASE_SHORT = {
  "Grupos": "Grupos",
  "Octavos": "32avos",
  "Cuartos de Octavos": "16avos",
  "Cuartos": "Cuartos",
  "Semifinal": "Semis",
  "Tercer puesto": "3er puesto",
  "Final": "Final",
};

const TEAMS = [...new Set(MATCHES.filter(m => m.phase === "Grupos").flatMap(m => [m.home, m.away]))].sort();

const TZ_OPTIONS = [
  { label: "Auto (dispositivo)", value: "auto" },
  { label: "GMT-4 (Santiago / Caracas)", value: -4 },
  { label: "GMT-5 (Bogotá / Lima / CDMX)", value: -5 },
  { label: "GMT-3 (Buenos Aires / São Paulo)", value: -3 },
  { label: "GMT-6 (CDMX invierno)", value: -6 },
  { label: "GMT+0 (Londres)", value: 0 },
  { label: "GMT+1 (Madrid / París)", value: 1 },
  { label: "GMT+2 (El Cairo)", value: 2 },
  { label: "GMT+9 (Tokio)", value: 9 },
];

const FLAG_MAP = {
  "México": "🇲🇽", "Sudáfrica": "🇿🇦", "Corea del Sur": "🇰🇷", "Chequia": "🇨🇿",
  "Canadá": "🇨🇦", "Bosnia y Herzegovina": "🇧🇦", "Estados Unidos": "🇺🇸", "Paraguay": "🇵🇾",
  "Qatar": "🇶🇦", "Suiza": "🇨🇭", "Brasil": "🇧🇷", "Marruecos": "🇲🇦",
  "Haití": "🇭🇹", "Escocia": "🏴󠁧󠁢󠁳󠁣󠁴󠁿", "Australia": "🇦🇺", "Turquía": "🇹🇷",
  "Alemania": "🇩🇪", "Curazao": "🇨🇼", "Países Bajos": "🇳🇱", "Japón": "🇯🇵",
  "Costa de Marfil": "🇨🇮", "Ecuador": "🇪🇨", "Suecia": "🇸🇪", "Túnez": "🇹🇳",
  "España": "🇪🇸", "Cabo Verde": "🇨🇻", "Bélgica": "🇧🇪", "Egipto": "🇪🇬",
  "Arabia Saudita": "🇸🇦", "Uruguay": "🇺🇾", "Irán": "🇮🇷", "Nueva Zelanda": "🇳🇿",
  "Francia": "🇫🇷", "Senegal": "🇸🇳", "Irak": "🇮🇶", "Noruega": "🇳🇴",
  "Argentina": "🇦🇷", "Argelia": "🇩🇿", "Austria": "🇦🇹", "Jordania": "🇯🇴",
  "Portugal": "🇵🇹", "RD Congo": "🇨🇩", "Inglaterra": "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "Croacia": "🇭🇷",
  "Ghana": "🇬🇭", "Panamá": "🇵🇦", "Uzbekistán": "🇺🇿", "Colombia": "🇨🇴",
};

const COUNTRY_MAP = {
  "Ciudad de México": "🇲🇽", "Zapopan": "🇲🇽", "Monterrey": "🇲🇽",
  "Toronto": "🇨🇦", "Vancouver": "🇨🇦",
};

// ─── UTILITIES ────────────────────────────────────────────────────
function getDeviceOffset() {
  return -(new Date().getTimezoneOffset() / 60);
}

function adjustTime(timeStr, dateStr, fromOffsetET, toOffset) {
  const [h, m] = timeStr.split(":").map(Number);
  const diff = toOffset - fromOffsetET;
  let newH = h + diff;
  let dayShift = 0;
  if (newH >= 24) { newH -= 24; dayShift = 1; }
  if (newH < 0) { newH += 24; dayShift = -1; }
  let newDate = dateStr;
  if (dayShift !== 0) {
    const d = new Date(dateStr + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + dayShift);
    newDate = d.toISOString().slice(0, 10);
  }
  return { time: `${String(newH).padStart(2, "0")}:${String(m).padStart(2, "0")}`, date: newDate };
}

function formatDate(dateStr) {
  const d = new Date(dateStr + "T12:00:00Z");
  const days = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  const months = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
  return `${days[d.getUTCDay()]} ${d.getUTCDate()} ${months[d.getUTCMonth()]}`;
}

function generateICS(matches, tzOffset) {
  const tzLabel = tzOffset >= 0 ? `+${String(tzOffset).padStart(2, "0")}00` : `-${String(Math.abs(tzOffset)).padStart(2, "0")}00`;
  let cal = `BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//WorldCup2026//Dashboard//ES\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\n`;
  matches.forEach((m) => {
    const adj = adjustTime(m.time, m.date, -4, tzOffset);
    const [h, min] = adj.time.split(":").map(Number);
    const dtStr = adj.date.replace(/-/g, "");
    const startStr = `${dtStr}T${String(h).padStart(2, "0")}${String(min).padStart(2, "0")}00`;
    const endH = h + 2;
    const endStr = `${dtStr}T${String(endH).padStart(2, "0")}${String(min).padStart(2, "0")}00`;
    const uid = `wc2026-match-${m.id}@dashboard`;
    cal += `BEGIN:VEVENT\r\n`;
    cal += `UID:${uid}\r\n`;
    cal += `DTSTART:${startStr}\r\n`;
    cal += `DTEND:${endStr}\r\n`;
    cal += `SUMMARY:⚽ ${m.home} vs ${m.away}\r\n`;
    cal += `LOCATION:${m.venue}, ${m.city}\r\n`;
    cal += `DESCRIPTION:${PHASE_SHORT[m.phase] || m.phase}${m.group ? ` - Grupo ${m.group}` : ""} | FIFA World Cup 2026\r\n`;
    cal += `BEGIN:VALARM\r\nTRIGGER:-PT15M\r\nACTION:DISPLAY\r\nDESCRIPTION:⚽ ${m.home} vs ${m.away} comienza en 15 minutos\r\nEND:VALARM\r\n`;
    cal += `END:VEVENT\r\n`;
  });
  cal += `END:VCALENDAR\r\n`;
  return cal;
}

// ─── COMPONENTS ───────────────────────────────────────────────────
function MatchCard({ match, starred, onToggle, tzOffset }) {
  const etOffset = -4;
  const adj = adjustTime(match.time, match.date, etOffset, tzOffset);
  const isKnockout = match.phase !== "Grupos";
  const homeFlag = FLAG_MAP[match.home];
  const awayFlag = FLAG_MAP[match.away];
  const countryFlag = COUNTRY_MAP[match.city];

  return (
    <div
      style={{
        background: starred ? "var(--card-starred)" : "var(--card-bg)",
        border: starred ? "1px solid var(--accent)" : "1px solid var(--border)",
        borderRadius: 10,
        padding: "14px 16px",
        transition: "all 0.2s ease",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {isKnockout && (
        <div style={{
          position: "absolute", top: 0, right: 0,
          background: match.phase === "Final" ? "var(--gold)" : "var(--accent)",
          color: "#fff", fontSize: 9, fontWeight: 700,
          padding: "3px 10px 3px 12px",
          borderRadius: "0 0 0 8px",
          letterSpacing: "0.05em", textTransform: "uppercase",
          fontFamily: "'DM Sans', sans-serif",
        }}>
          {PHASE_SHORT[match.phase] || match.phase}
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Teams */}
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 20, lineHeight: 1 }}>{homeFlag || "🏳️"}</span>
              <span style={{
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: 600, fontSize: 14, color: "var(--text-primary)",
                whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
              }}>
                {match.home}
              </span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 20, lineHeight: 1 }}>{awayFlag || "🏳️"}</span>
              <span style={{
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: 600, fontSize: 14, color: "var(--text-primary)",
                whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
              }}>
                {match.away}
              </span>
            </div>
          </div>

          {/* Meta */}
          <div style={{
            display: "flex", flexWrap: "wrap", gap: "4px 12px",
            marginTop: 10, fontSize: 11, color: "var(--text-muted)",
            fontFamily: "'DM Sans', sans-serif",
          }}>
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <Clock size={11} strokeWidth={2} />
              {adj.time}
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <MapPin size={11} strokeWidth={2} />
              {countryFlag ? `${countryFlag} ` : ""}{match.city}
            </span>
            {match.group && (
              <span style={{
                background: "var(--group-badge)", color: "var(--text-secondary)",
                padding: "1px 6px", borderRadius: 4, fontWeight: 600, fontSize: 10,
                letterSpacing: "0.03em",
              }}>
                Grupo {match.group}
              </span>
            )}
          </div>
        </div>

        {/* Star button */}
        <button
          onClick={() => onToggle(match.id)}
          style={{
            background: "none", border: "none", cursor: "pointer",
            padding: 6, borderRadius: 8, flexShrink: 0,
            color: starred ? "var(--accent)" : "var(--text-muted)",
            transition: "all 0.15s ease",
          }}
          aria-label={starred ? "Quitar de favoritos" : "Marcar como favorito"}
        >
          <Star size={20} fill={starred ? "var(--accent)" : "none"} strokeWidth={1.8} />
        </button>
      </div>
    </div>
  );
}

function Pill({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      style={{
        fontFamily: "'DM Sans', sans-serif",
        fontSize: 12, fontWeight: active ? 600 : 500,
        padding: "6px 14px", borderRadius: 20,
        border: active ? "1px solid var(--accent)" : "1px solid var(--border)",
        background: active ? "var(--accent)" : "var(--card-bg)",
        color: active ? "#fff" : "var(--text-secondary)",
        cursor: "pointer", whiteSpace: "nowrap",
        transition: "all 0.15s ease",
        letterSpacing: "0.01em",
      }}
    >
      {children}
    </button>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────
export default function WorldCupDashboard() {
  const [starred, setStarred] = useState(() => {
    try { return new Set(JSON.parse(window._wc_starred || "[]")); }
    catch { return new Set(); }
  });
  const [searchTeam, setSearchTeam] = useState("");
  const [filterGroup, setFilterGroup] = useState(null);
  const [filterPhase, setFilterPhase] = useState(null);
  const [showStarredOnly, setShowStarredOnly] = useState(false);
  const [tzSetting, setTzSetting] = useState("auto");
  const [showFilters, setShowFilters] = useState(false);
  const [showTzPicker, setShowTzPicker] = useState(false);

  const tzOffset = tzSetting === "auto" ? getDeviceOffset() : tzSetting;

  const toggleStar = useCallback((id) => {
    setStarred((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      try { window._wc_starred = JSON.stringify([...next]); } catch {}
      return next;
    });
  }, []);

  const filtered = useMemo(() => {
    let list = MATCHES;
    if (showStarredOnly) list = list.filter((m) => starred.has(m.id));
    if (filterGroup) list = list.filter((m) => m.group === filterGroup);
    if (filterPhase) list = list.filter((m) => m.phase === filterPhase);
    if (searchTeam) {
      const q = searchTeam.toLowerCase();
      list = list.filter((m) => m.home.toLowerCase().includes(q) || m.away.toLowerCase().includes(q));
    }
    return list;
  }, [showStarredOnly, filterGroup, filterPhase, searchTeam, starred]);

  const grouped = useMemo(() => {
    const etOffset = -4;
    const map = new Map();
    filtered.forEach((m) => {
      const adj = adjustTime(m.time, m.date, etOffset, tzOffset);
      const key = adj.date;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(m);
    });
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [filtered, tzOffset]);

  const starredMatches = useMemo(() => MATCHES.filter((m) => starred.has(m.id)), [starred]);

  const downloadICS = async () => {
    if (starredMatches.length === 0) return;
    const ics = generateICS(starredMatches, tzOffset);
    const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
    const file = new File([blob], "mundial_2026.ics", { type: "text/calendar" });

    // 1) Try Web Share API (works great on iOS Safari)
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: "Mundial 2026", text: "Mis partidos del Mundial 2026" });
        return;
      } catch (e) {
        if (e.name === "AbortError") return; // user cancelled
      }
    }

    // 2) Fallback: data URI open in new tab (iOS Safari compat)
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const link = document.createElement("a");
      link.href = dataUrl;
      link.download = "mundial_2026.ics";
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        document.body.removeChild(link);
      }, 100);
    };
    reader.readAsDataURL(blob);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=Instrument+Serif:ital@0;1&display=swap');
        :root {
          --bg: #fafaf9;
          --card-bg: #ffffff;
          --card-starred: #fef9f0;
          --border: #e8e5e0;
          --text-primary: #1a1917;
          --text-secondary: #57534e;
          --text-muted: #a8a29e;
          --accent: #b45309;
          --accent-light: #fef3c7;
          --gold: #d97706;
          --group-badge: #f5f0eb;
          --danger: #dc2626;
        }
        @media (prefers-color-scheme: dark) {
          :root {
            --bg: #0c0a09;
            --card-bg: #1c1917;
            --card-starred: #1c1710;
            --border: #292524;
            --text-primary: #fafaf9;
            --text-secondary: #a8a29e;
            --text-muted: #78716c;
            --accent: #f59e0b;
            --accent-light: #451a03;
            --gold: #f59e0b;
            --group-badge: #292524;
          }
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: var(--bg); }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }
        input::placeholder { color: var(--text-muted); }
        button:active { transform: scale(0.97); }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .match-enter { animation: fadeIn 0.25s ease both; }
      `}</style>

      <div style={{
        fontFamily: "'DM Sans', sans-serif",
        background: "var(--bg)", color: "var(--text-primary)",
        minHeight: "100vh", maxWidth: 520, margin: "0 auto",
        padding: "0 16px 80px",
      }}>
        {/* Header */}
        <header style={{
          padding: "28px 0 20px",
          borderBottom: "1px solid var(--border)",
          marginBottom: 16,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
            <Trophy size={18} color="var(--accent)" strokeWidth={2.2} />
            <span style={{
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 10, fontWeight: 700, letterSpacing: "0.12em",
              textTransform: "uppercase", color: "var(--accent)",
            }}>
              FIFA World Cup
            </span>
          </div>
          <h1 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: 32, fontWeight: 400, lineHeight: 1.1,
            color: "var(--text-primary)", marginTop: 4,
          }}>
            Mundial 2026
          </h1>
          <p style={{
            fontSize: 13, color: "var(--text-muted)",
            marginTop: 6, fontWeight: 400,
          }}>
            EE.UU. · México · Canadá — 11 Jun – 19 Jul
          </p>
        </header>

        {/* TZ + Controls Row */}
        <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
          <button
            onClick={() => setShowTzPicker(!showTzPicker)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: "var(--card-bg)", border: "1px solid var(--border)",
              borderRadius: 8, padding: "7px 12px", cursor: "pointer",
              fontSize: 12, color: "var(--text-secondary)",
              fontFamily: "'DM Sans', sans-serif", fontWeight: 500,
            }}
          >
            <Globe size={13} />
            GMT{tzOffset >= 0 ? "+" : ""}{tzOffset}
            <ChevronDown size={12} />
          </button>

          <button
            onClick={() => setShowFilters(!showFilters)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: (filterGroup || filterPhase) ? "var(--accent)" : "var(--card-bg)",
              border: "1px solid var(--border)",
              borderRadius: 8, padding: "7px 12px", cursor: "pointer",
              fontSize: 12,
              color: (filterGroup || filterPhase) ? "#fff" : "var(--text-secondary)",
              fontFamily: "'DM Sans', sans-serif", fontWeight: 500,
            }}
          >
            <Filter size={13} />
            Filtros
            {(filterGroup || filterPhase) && (
              <span style={{
                background: "rgba(255,255,255,0.25)", borderRadius: 10,
                padding: "0 5px", fontSize: 10,
              }}>
                {[filterGroup && `G${filterGroup}`, filterPhase && PHASE_SHORT[filterPhase]].filter(Boolean).join(", ")}
              </span>
            )}
          </button>

          <button
            onClick={() => { setShowStarredOnly(!showStarredOnly); }}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: showStarredOnly ? "var(--accent)" : "var(--card-bg)",
              border: "1px solid var(--border)",
              borderRadius: 8, padding: "7px 12px", cursor: "pointer",
              fontSize: 12,
              color: showStarredOnly ? "#fff" : "var(--text-secondary)",
              fontFamily: "'DM Sans', sans-serif", fontWeight: 500,
              marginLeft: "auto",
            }}
          >
            <Star size={13} fill={showStarredOnly ? "#fff" : "none"} />
            {starred.size}
          </button>
        </div>

        {/* TZ Picker */}
        {showTzPicker && (
          <div style={{
            background: "var(--card-bg)", border: "1px solid var(--border)",
            borderRadius: 10, padding: 12, marginBottom: 12,
            animation: "fadeIn 0.2s ease",
          }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "var(--text-muted)", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.06em" }}>
              Zona horaria
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {TZ_OPTIONS.map((tz) => (
                <button
                  key={String(tz.value)}
                  onClick={() => { setTzSetting(tz.value); setShowTzPicker(false); }}
                  style={{
                    display: "flex", alignItems: "center", justifyContent: "space-between",
                    background: tzSetting === tz.value ? "var(--accent-light)" : "transparent",
                    border: "none", borderRadius: 6, padding: "8px 10px",
                    cursor: "pointer", fontSize: 12, color: "var(--text-primary)",
                    fontFamily: "'DM Sans', sans-serif", fontWeight: tzSetting === tz.value ? 600 : 400,
                  }}
                >
                  {tz.label}
                  {tzSetting === tz.value && <Check size={14} color="var(--accent)" />}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Filters Panel */}
        {showFilters && (
          <div style={{
            background: "var(--card-bg)", border: "1px solid var(--border)",
            borderRadius: 10, padding: 14, marginBottom: 12,
            animation: "fadeIn 0.2s ease",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                Filtrar partidos
              </span>
              {(filterGroup || filterPhase) && (
                <button onClick={() => { setFilterGroup(null); setFilterPhase(null); }}
                  style={{ background: "none", border: "none", cursor: "pointer", fontSize: 11, color: "var(--accent)", fontWeight: 600, fontFamily: "'DM Sans', sans-serif" }}>
                  Limpiar
                </button>
              )}
            </div>

            <div style={{ fontSize: 11, fontWeight: 500, color: "var(--text-muted)", marginBottom: 6 }}>Grupo</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: 12 }}>
              {GROUPS.map((g) => (
                <Pill key={g} active={filterGroup === g} onClick={() => setFilterGroup(filterGroup === g ? null : g)}>
                  {g}
                </Pill>
              ))}
            </div>

            <div style={{ fontSize: 11, fontWeight: 500, color: "var(--text-muted)", marginBottom: 6 }}>Fase</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
              {PHASES.map((p) => (
                <Pill key={p} active={filterPhase === p} onClick={() => setFilterPhase(filterPhase === p ? null : p)}>
                  {PHASE_SHORT[p]}
                </Pill>
              ))}
            </div>
          </div>
        )}

        {/* Search */}
        <div style={{ position: "relative", marginBottom: 16 }}>
          <Search size={15} style={{
            position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)",
            color: "var(--text-muted)",
          }} />
          <input
            type="text"
            placeholder="Buscar selección..."
            value={searchTeam}
            onChange={(e) => setSearchTeam(e.target.value)}
            style={{
              width: "100%",
              background: "var(--card-bg)", border: "1px solid var(--border)",
              borderRadius: 10, padding: "10px 12px 10px 36px",
              fontSize: 13, color: "var(--text-primary)",
              fontFamily: "'DM Sans', sans-serif",
              outline: "none",
            }}
          />
          {searchTeam && (
            <button
              onClick={() => setSearchTeam("")}
              style={{
                position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)",
              }}
            >
              <X size={14} />
            </button>
          )}
        </div>

        {/* Download ICS Bar */}
        {starredMatches.length > 0 && (
          <button
            onClick={downloadICS}
            style={{
              width: "100%",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              background: "var(--accent)", color: "#fff",
              border: "none", borderRadius: 10, padding: "12px 16px",
              cursor: "pointer", fontSize: 13, fontWeight: 600,
              fontFamily: "'DM Sans', sans-serif",
              marginBottom: 20,
              boxShadow: "0 2px 8px rgba(180,83,9,0.2)",
              transition: "all 0.15s ease",
            }}
          >
            <Calendar size={16} />
            Descargar {starredMatches.length} partido{starredMatches.length !== 1 ? "s" : ""} (.ics)
            <Bell size={14} style={{ opacity: 0.7 }} />
          </button>
        )}

        {/* Stats Row */}
        <div style={{
          display: "flex", gap: 8, marginBottom: 16,
        }}>
          <div style={{
            flex: 1, background: "var(--card-bg)", border: "1px solid var(--border)",
            borderRadius: 10, padding: "10px 14px", textAlign: "center",
          }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)", fontFamily: "'DM Sans', sans-serif" }}>
              {filtered.length}
            </div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
              Partidos
            </div>
          </div>
          <div style={{
            flex: 1, background: "var(--card-bg)", border: "1px solid var(--border)",
            borderRadius: 10, padding: "10px 14px", textAlign: "center",
          }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: "var(--accent)", fontFamily: "'DM Sans', sans-serif" }}>
              {starred.size}
            </div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
              Favoritos
            </div>
          </div>
          <div style={{
            flex: 1, background: "var(--card-bg)", border: "1px solid var(--border)",
            borderRadius: 10, padding: "10px 14px", textAlign: "center",
          }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)", fontFamily: "'DM Sans', sans-serif" }}>
              {grouped.length}
            </div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
              Jornadas
            </div>
          </div>
        </div>

        {/* Match List */}
        {grouped.length === 0 ? (
          <div style={{
            textAlign: "center", padding: "48px 20px",
            color: "var(--text-muted)", fontSize: 14,
          }}>
            <Search size={32} style={{ marginBottom: 12, opacity: 0.4 }} />
            <p>No se encontraron partidos</p>
            <p style={{ fontSize: 12, marginTop: 4 }}>Ajusta los filtros o la búsqueda</p>
          </div>
        ) : (
          grouped.map(([date, dayMatches], di) => (
            <div key={date} className="match-enter" style={{ animationDelay: `${di * 0.03}s`, marginBottom: 20 }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 8,
                marginBottom: 10, position: "sticky", top: 0,
                background: "var(--bg)", zIndex: 2, paddingTop: 4, paddingBottom: 4,
              }}>
                <div style={{
                  fontSize: 12, fontWeight: 700, color: "var(--text-secondary)",
                  fontFamily: "'DM Sans', sans-serif",
                  letterSpacing: "0.02em",
                }}>
                  {formatDate(date)}
                </div>
                <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
                <span style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500 }}>
                  {dayMatches.length} partido{dayMatches.length !== 1 ? "s" : ""}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {dayMatches.map((m) => (
                  <MatchCard
                    key={m.id}
                    match={m}
                    starred={starred.has(m.id)}
                    onToggle={toggleStar}
                    tzOffset={tzOffset}
                  />
                ))}
              </div>
            </div>
          ))
        )}

        {/* Footer */}
        <div style={{
          textAlign: "center", padding: "32px 0 16px",
          fontSize: 10, color: "var(--text-muted)", lineHeight: 1.6,
          borderTop: "1px solid var(--border)", marginTop: 20,
        }}>
          Horarios en GMT{tzOffset >= 0 ? "+" : ""}{tzOffset} · Alarma 15 min antes del inicio
          <br />
          Los horarios corresponden a la zona horaria seleccionada
        </div>
      </div>
    </>
  );
}
